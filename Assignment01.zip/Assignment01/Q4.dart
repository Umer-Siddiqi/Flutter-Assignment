void main(){
    int year = 1900;
   if   (year % 4==0){

  print("Leap year $year");
   }
   else if(year % 400==0){

  print("century year $year");
   }
   else{ 
   print("none of the above");
   }

}