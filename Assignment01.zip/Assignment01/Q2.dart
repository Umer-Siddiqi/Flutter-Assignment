void main(){
  int sameer = 20;
  int umer = 22;

  if(sameer > umer){
    print("Sameer is oldest");
  }
  else if(sameer == umer){
    print("Both are at same age");
  }
  else{
    print("Umer is the oldest");
  }
}