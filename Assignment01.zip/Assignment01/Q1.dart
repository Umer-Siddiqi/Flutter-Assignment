void main(){

 
  int length = 4;
  int breadth = 20;

  if(length == breadth){
  print("The values are square");
}
  else{
    print("The values are rectangle");
  }

}